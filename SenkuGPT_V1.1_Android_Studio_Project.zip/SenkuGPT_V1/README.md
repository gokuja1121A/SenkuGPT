# SenkuGPT V1 - Android Studio starter project

**App name:** SenkuGPT  
**Version:** 1.0  
**Tagline:** This Is Exhilarating!  
**Target:** Android 11+ (minSdk 23)

## Included in this first project pass
- Native Kotlin Android shell with WebViewAssetLoader (HTTPS-style local origin, not `file://`).
- Rebranded green Senku-inspired interface based on the supplied StudyGPT Lite v0.9.2 HTML.
- Existing chat/profile localStorage keys retained in the web app.
- Native Android document picker and one-time copy of the selected GGUF into app-private storage.
- Automatic attempt to reopen the stored model on later launches.
- Senku-inspired system prompt and anime-only Dr. Stone spoiler boundary.

## Important: not a finished APK yet
This is an Android Studio source starter, **not a compiled or tested APK**. The Wllama JavaScript + WASM runtime is not included in this archive, so actual model inference will not start until the matching Wllama v3 runtime files are added under:

`app/src/main/assets/www/wllama/esm/index.js`

`app/src/main/assets/www/wllama/esm/wasm/wllama.wasm`

The HTML expects the Wllama `Wllama` export and `loadModel([blob], ...)` API. Verify this against the exact runtime version before building. No runtime is downloaded at launch; the final app must bundle it to remain offline.

The app currently imports the selected file into app-private storage using the V1 model filename. The file picker accepts generic document types because Android providers vary in their GGUF MIME type. Select the supplied `SmolLM2-135M-Instruct-Q4_K_S.gguf` file.

## Build environment
Open this folder in Android Studio with JDK 17 and Android SDK Platform 35 installed. Let Gradle sync, then build the debug APK. This environment did not have Gradle or the Android SDK installed, so no APK could be compiled or device-tested here.

## Known V1 work still required
1. Add and verify the pinned Wllama JS/WASM runtime files.
2. Test import, persistent model loading, inference, memory use and crash behavior on Android 11 / Samsung Galaxy A30s.
3. Add the requested chat-backup export/import flow to migrate old `file://` WebView localStorage into the new app origin. Retaining the old storage keys alone cannot transfer data between origins.
4. Expand the Dr. Stone anime knowledge base and implement a reliable spoiler-warning flow. The current system prompt is only a basic boundary, not a complete knowledge base.
5. Add a dedicated Science Mode toggle and test it.

## Storage estimate
APK size is not measured yet. The earlier under-25-MB figure is a target, not a verified build size. The GGUF stays outside the APK and is about 102 MB.
