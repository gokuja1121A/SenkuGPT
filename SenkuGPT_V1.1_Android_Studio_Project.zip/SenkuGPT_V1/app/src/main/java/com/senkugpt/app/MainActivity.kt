package com.senkugpt.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private val modelDir by lazy { File(filesDir, "models").apply { mkdirs() } }

    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) importModel(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WebView.setWebContentsDebuggingEnabled(false)
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/models/", WebViewAssetLoader.InternalStoragePathHandler(this, modelDir))
            .build()

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = false
        webView.settings.allowContentAccess = false
        webView.addJavascriptInterface(SenkuBridge(), "SenkuNative")
        webView.webViewClient = object : android.webkit.WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }
        }
        setContentView(webView)
        webView.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    private inner class SenkuBridge {
        @JavascriptInterface fun getModelName(): String = modelDir.listFiles()?.firstOrNull { it.isFile && it.extension.equals("gguf", true) }?.name ?: ""
        @JavascriptInterface fun pickModel() { runOnUiThread { modelPicker.launch(arrayOf("application/octet-stream", "*/*")) } }
    }

    private fun importModel(uri: Uri) {
        try {
            val displayName = "SmolLM2-135M-Instruct-Q4_K_S.gguf"
            val target = File(modelDir, displayName)
            contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { output -> input.copyTo(output) } }
                ?: throw IllegalStateException("Could not open selected file")
            webView.evaluateJavascript("window.onSenkuModelImported && window.onSenkuModelImported(${org.json.JSONObject.quote(displayName)})", null)
        } catch (e: Exception) {
            webView.evaluateJavascript("alert(${org.json.JSONObject.quote("Model import failed: ${e.message}")})", null)
        }
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}
